def main():
    print("Let's play a guessing game!")
    print("Guess the correct number between 1-10 and you win!")
    print("You are allowed 7 guesses MAX, goodluck player!")

    player = input('Enter your name, player: ')

    win_num = 3
    guessList = []
    keepGoing = True

    while keepGoing == True and len(guessList) < 7:
        guess = int(input('Enter guess ' + str(player) + ': '))
        guessList.append(guess)
        if guess == win_num:
            keepGoing = False
            print('You are correct, ' + str(player) + '!')
            print('You guessed this amount of times: ')
            print(len(guessList))
            print('Number(s) guessed before winning: ')
            print(guessList)
        if len(guessList) == 7 and guess != win_num:
            keepGoing = False
            print('Sorry ' + str(player) + ', you lost!')
            print('Number(s) guessed: ')
            print(guessList)
            print('The correct answer is ' + str(win_num))
        if guess != win_num and keepGoing == True:
            print('Sorry that is incorrect, try again.')


main()
